(function($) {
      $(document).ready(function() {
        console.log('Optimole Templates admin scripts loaded');
      });
    })(jQuery);